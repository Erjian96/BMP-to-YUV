#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <windows.h>
#include <math.h>
#include "rgb2yuv.h"

#define u_int8_t	unsigned __int8
#define u_int		unsigned __int32
#define u_int32_t	unsigned __int32
#define FALSE		false
#define TRUE		true

/*
 * bmp2yuv
 * required arg1 should be the input RAW bmp file
 * required arg2 should be the output RAW YUV12 file
 */ 
int main(int argc, char** argv)
{	
	BITMAPFILEHEADER File_header;
	BITMAPINFOHEADER Info_header;
	/* variables controlable from command line */
	u_int frameWidth = 352;			/* --width=<uint> */
	u_int frameHeight = 240;		/* --height=<uint> */
	bool flip = TRUE;				/* --flip */
	unsigned int i,j;
	int t[5] = {NULL};
	int fream;
	/* internal variables */
	char* bmpFileName[5] = {NULL};
	char* yuvFileName = NULL;
	FILE* bmpFile[5] = {NULL};
	FILE* yuvFile = NULL;
	u_int8_t* rgbBuf = NULL;
	unsigned char* rgbBuf1 = NULL;
	u_int8_t* yBuf = NULL;
	u_int8_t* uBuf = NULL;
	u_int8_t* vBuf = NULL;
	unsigned char* Data = NULL;
	u_int32_t videoFramesWritten = 0;
	/* begin process command line */
	/* point to the specified file names */
	bmpFileName[0] = argv[1];
	t[0] = atoi(argv[2]);
	bmpFileName[1] = argv[3];
	t[1] = atoi(argv[4]);
	bmpFileName[2] = argv[5];
	t[2] = atoi(argv[6]);
	bmpFileName[3] = argv[7];
	t[3] = atoi(argv[8]);
	bmpFileName[4] = argv[9];
	t[4] = atoi(argv[10]);
	yuvFileName = argv[11];
	fream = atoi(argv[12]);
	/* open the RAW file */
	yuvFile = fopen(yuvFileName, "wb");
	if (yuvFile == NULL)
	{
		printf("cannot find yuv file\n");
		exit(1);
	}
	else
	{
		printf("The output yuv file is %s\n", yuvFileName);
	}
	/* open the BMP file */
	//	read file & info header
		for( j = 0; j < fream ;j++)//number of picture
		{
			for( int m = 0; m <t[j] ; m++ )//time of each picture
			{
				bmpFile[j] = fopen(bmpFileName[j], "rb");
				if(bmpFile[j] == NULL)  
				{  
					 printf("bmpfile open error!\n");  
					 exit(0);  
				}  
				if(fread(&File_header,sizeof(BITMAPFILEHEADER),1,bmpFile[j]) != 1)
				{
					printf("read file header error!");
					exit(0);
				}
				if (File_header.bfType != 0x4D42)
				{
					printf("Not bmp file!");
					exit(0);
				}
				else
				{	
					printf("this is a BmpFile\n");
					flip = FALSE;
				} 
				if(fread(&Info_header,sizeof(BITMAPINFOHEADER),1,bmpFile[j]) != 1)
				{	
					printf("read info header error!");
					exit(0);
				}
				frameWidth = Info_header.biWidth;
				frameHeight = Info_header.biHeight;
				//	end read header
				/* get an middle buffer for a frame */
				rgbBuf = (u_int8_t*)malloc(frameWidth * frameHeight * 3);//
				/* get the output buffers for a frame */
				yBuf = (u_int8_t*)malloc(frameWidth * frameHeight);
				uBuf = (u_int8_t*)malloc((frameWidth * frameHeight) / 4);
				vBuf = (u_int8_t*)malloc((frameWidth * frameHeight) / 4);
				if (rgbBuf == NULL || yBuf == NULL || uBuf == NULL || vBuf == NULL)
				{
					printf("no enought memory\n");
					exit(1);
				}
   
				if(Info_header.biBitCount == 24)
				{
					
					fread(rgbBuf, 1, frameWidth * frameHeight * 3, bmpFile[j]);
				}
				else
				{
					rgbBuf1 = (unsigned char*)rgbBuf;//
					if(Info_header.biBitCount == 16)
					{
						Data = (unsigned char*)malloc(frameWidth * frameHeight*2); 
						fseek(bmpFile[j],File_header.bfOffBits,0); 
						fread(Data, 1, frameWidth * frameHeight * 2, bmpFile[j]);
						for (int Loop = 0; Loop < frameHeight * frameWidth * 2 ;Loop += 2)//565
						{
							*rgbBuf1 = (Data[Loop]&0x1F)<<3;//00011111=>11111000
							*(rgbBuf1 + 1) = ((Data[Loop]&0xE0)>>3) + ((Data[Loop+1]&0x07)<<5);//11100000=>00011100and00000111=>11100000
							*(rgbBuf1 + 2) = (Data[Loop+1]&0xF8);
							rgbBuf1 +=3;
						}
					if(Data)free(Data);	
					}
					else
					{
						RGBQUAD *pRGB = (RGBQUAD *)malloc(sizeof(RGBQUAD)*(unsigned int)pow((float)2,Info_header.biBitCount));//?
						if(!MakePalette(bmpFile[j],File_header,Info_header,pRGB))
						printf("No palette!");
						if(Info_header.biBitCount == 8)
						{
							Data = (unsigned char*)malloc(frameWidth * frameHeight);
							fseek(bmpFile[j],File_header.bfOffBits,0);  
							fread(Data, 1, frameWidth * frameHeight, bmpFile[j]);
						}
						if(Info_header.biBitCount == 4)
						{
							Data = (unsigned char*)malloc(frameWidth * frameHeight*4/8);
							fseek(bmpFile[j],File_header.bfOffBits,0);  
							fread(Data, 1, frameWidth * frameHeight * 4/8, bmpFile[j]);
						}
						if(Info_header.biBitCount == 1)
						{
							Data = (unsigned char*)malloc(frameWidth * frameHeight*1/8);
							fseek(bmpFile[j],File_header.bfOffBits,0);  
							fread(Data, 1, frameWidth * frameHeight * 1/8, bmpFile[j]);
						}
						for (int Loop =0; Loop<frameWidth * frameHeight/(8/Info_header.biBitCount); Loop++)//?  
						{
							unsigned char mask = 0;
							/*mask = (unsigned char)pow((float)2, Info_header.biBitCount) - 1;  
							mask = mask << (8-Info_header.biBitCount);  */
							if(Info_header.biBitCount == 8)
							{
								mask = 0xFF;
							}
							if(Info_header.biBitCount == 4)
							{
								mask = 0xF0;
							}
							if(Info_header.biBitCount == 1)
							{
								mask = 0x80;
							}
							int shiftCnt = 1;
							while (mask)
							{
								unsigned char index = mask == 0xFF ? Data[Loop] : ((Data[Loop] & mask)>>(8 - shiftCnt * Info_header.biBitCount));
								* rgbBuf1 = pRGB[index].rgbBlue;
								* (rgbBuf1+1) = pRGB[index].rgbGreen;
								* (rgbBuf1+2) = pRGB[index].rgbRed;
								if(Info_header.biBitCount == 8)	mask = 0;
								else mask >>= Info_header.biBitCount; 
								rgbBuf1 += 3;
								shiftCnt ++;		
							}	
							
						} 
					if(Data)free(Data);	
					if(pRGB)free(pRGB);
				
					}
				}	
				if(RGB2YUV(frameWidth, frameHeight, rgbBuf, yBuf, uBuf, vBuf, flip))
				{
					printf("error");
					return 0;
				}
				for (i = 0; i < frameWidth*frameHeight; i++)
				{
					if (yBuf[i] < 16) yBuf[i] = 16;
					if (yBuf[i] > 235) yBuf[i] = 235;
				}
				for (i = 0; i < frameWidth*frameHeight/4; i++)
				{
					if (uBuf[i] < 16) uBuf[i] = 16;
					if (uBuf[i] > 240) uBuf[i] = 240;
					if (vBuf[i] < 16) vBuf[i] = 16;
					if (vBuf[i] > 240) vBuf[i] = 240;
				}	
				fwrite(yBuf, 1, frameWidth * frameHeight, yuvFile);
				fwrite(uBuf, 1, (frameWidth * frameHeight) / 4, yuvFile);
				fwrite(vBuf, 1, (frameWidth * frameHeight) / 4, yuvFile);
				printf("\r...%d", ++videoFramesWritten);
				printf("\n%u %ux%u video frames written\n", 
				videoFramesWritten, frameWidth, frameHeight);
				fclose(bmpFile[j]);
				free(rgbBuf);
				free(yBuf);
				free(uBuf);
				free(vBuf);
				
			}	
		}
	/* cleanup */
	fclose(yuvFile);
	return(0);
}

