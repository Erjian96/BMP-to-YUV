#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>
#include "stdlib.h"
#include "rgb2yuv.h"

bool MakePalette(FILE * pFile,BITMAPFILEHEADER &file_h,BITMAPINFOHEADER & info_h,RGBQUAD *pRGB_out)
{
		if ((file_h.bfOffBits - sizeof(BITMAPFILEHEADER) - info_h.biSize) == sizeof(RGBQUAD)*pow((float)2,info_h.biBitCount))
		{
			fseek(pFile,sizeof(BITMAPFILEHEADER)+info_h.biSize,0);
			fread(pRGB_out,sizeof(RGBQUAD),(unsigned int)pow((float)2,info_h.biBitCount),pFile);
			return true;
		}else
		return false;
}
